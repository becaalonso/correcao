package com.example.correcao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrjCorrecaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
